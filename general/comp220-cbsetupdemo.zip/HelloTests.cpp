
#include <string>
#include <cctype>
#include <gtest/gtest.h>

namespace {

    TEST(dubtests,all){
        EXPECT_DOUBLE_EQ(3.0,1.5+1.5);
        EXPECT_NEAR(6.25,2.5*2.5,0.0000001);
    }

    TEST(inttests,all){
        EXPECT_EQ(3,1+2);
        EXPECT_EQ(2,5/2);
    }

    TEST(chartests,all){
        EXPECT_EQ('A',toupper('a'));
        EXPECT_EQ('A',toupper('A'));
        EXPECT_EQ('x',tolower(('X')));
    }

    TEST(strtests,all){
        std::string s{"hello"};

        EXPECT_EQ(std::string("he"), s.substr(0,2) );
        EXPECT_EQ(std::string("lo"), s.substr(3));

    }

    TEST(booltests,all){
        EXPECT_TRUE(1 == 1);
        EXPECT_FALSE(1 == 2);
    }


}
