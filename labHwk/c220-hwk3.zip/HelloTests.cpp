/**
 * Logan Mayfield
 *   Simple tests that demonstrate Google Tests Test Fixtures and
 *   some StanfordCPP vector functionality.
 */

#include <gtest/gtest.h>
#include <string>
#include <cctype>
#include <cmath>
#include "vector.h"
#include "random.h"


namespace {

    // The fixture for testing class Foo.
    class VectorTest : public ::testing::Test {
        protected:
            VectorTest() {
                //Initialize the vectors here

                //fill sorted with increasing powers of 2
                for(int i{0}; i < 10; ++i){
                    sorted.add(pow(2,i));
                }

                // fill random with random doubles from [0,1]
                // see Chap 2 for some details on random.h, which
                // provides randomReal
                for(int i{0}; i < 15; ++i){
                    random.add(randomReal(0.0,1.0));
                }

            }

            // Declare Vector variables here
            Vector<int> MT; // the empty vector
            Vector<int> sorted;
            Vector<double> random;

    }; // end class VectorTests

    // Tests that the Foo::Bar() method does Abc.
    TEST_F(VectorTest, size) {
        EXPECT_EQ(0,MT.size());
        EXPECT_TRUE(MT.isEmpty());
        EXPECT_EQ(10,sorted.size());
        EXPECT_EQ(15,random.size());
    }

    TEST_F(VectorTest,removeAt){

        // before
        EXPECT_EQ(10,sorted.size());
        EXPECT_EQ(32,sorted[5]);
        // Mutate
        sorted.removeAt(5);
        //after
        EXPECT_EQ(9,sorted.size());
        EXPECT_EQ(64,sorted[5]);

    }

} // end namespace
