/**
 * Logan Mayfield
 *  A simple toy proram that utilizes some of the
 *  StanfordCPP library code
 *
 */

#include <iostream>
#include <iomanip>
#include "random.h"

int main() {

    std::cout << "10 Random doubles from [0,1]\n";
    for(int i{0}; i < 10; ++i){
        std::cout << std::setw(8) << std::setprecision(4) << std::fixed << std::left;
        std::cout << randomReal(0.0,1.0);
    }

   return 0;
}
